function calcular() {
    let n1 = Number(document.getElementById("n1").value)
    let n2 = Number(document.getElementById("n2").value)
    if (n2 != 0) {
        let res = n1 / n2
        alert(`O resultado da divisão entre eles é: ${res}.`)
    } else {
        alert("O segundo numero inserido deve ser diferente de 0!")
    }
    
}