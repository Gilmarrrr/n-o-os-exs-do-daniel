function calcular() {
    let kg = Number(document.getElementById("p").value)
    let g = kg * 1000
    alert(`Seu peso em gramas ${g}g.`)
}