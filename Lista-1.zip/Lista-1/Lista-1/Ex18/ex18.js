function converter() {
    let C = Number(document.getElementById("C").value)
    let F = (180 * (C + 31))/100
    alert(`A conversão de ${C}C° para Farenheit é ${F.toFixed(1)}F`)
}