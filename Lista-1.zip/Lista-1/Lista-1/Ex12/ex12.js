function calcular() {
    let salarioM = Number(document.getElementById("salarioM").value)
    let salario = Number(document.getElementById("salario").value)
    let quantidadeS = (salario / salarioM)
    alert(`A quantidade de salarios minimos ganhos é de ${quantidadeS.toFixed(1)}.`)
}