function calcular() {
    // ME² = DistanciaParede² + x² 
    
}