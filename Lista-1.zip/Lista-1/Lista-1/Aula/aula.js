function calcular() {
    //declarando variavel com o nome "n1" que está recebendo o valor do input de id "n1" e transformando em numero(number)
    let n1 = Number(document.getElementById("n1").value)
    let n2 = Number(document.getElementById("n2").value)
    let resultado = n1 - n2
    alert(resultado)
}