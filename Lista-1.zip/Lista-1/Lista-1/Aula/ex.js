var agora = new Date() //pega a data do sistema
var diaSem = agora.getDay() 
console.log(diaSem)  //6
switch(diaSem) {
    case 0:
        console.log("DOMINGO")
        break
    case 1:
        console.log("Segunda")
        break
}