function calcular() {
    let r = document.getElementById("res")
    let anoN = Number(document.getElementById("anoN").value)
    let anoA = Number(document.getElementById("anoA").value)
    let idadeA = anoA - anoN
    let idadeM = idadeA * 12
    let idadeD = idadeM * 30 + 7 /* meses com 31 dias*/ - 2 /*fevereiro tem 28*/
    let idadeS = idadeM * 4
    r.innerHTML = (`Sua idade em anos é: ${idadeA} <br> Sua idade em meses é: ${idadeM} <br> Sua idade em semanas é: ${idadeS} <br> Sua idade em dias é: ${idadeD}`)
}