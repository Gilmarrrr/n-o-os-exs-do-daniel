function calcular() {
    let R = Number(document.getElementById("raio").value)
    let res = document.getElementById("res")
    let C = 2 * (3.14 * R)
    let A = 3.14 * (R * R)
    let V = (4/3) * 3.14 * (R * R * R)
    res.innerHTML = (`Se ultilizarmos o raio ${R}cm obtemos: <br> Comprimento: ${C.toFixed(2)}cm <br> Área: ${A.toFixed(2)}cm² <br> Volume: ${V}cm³`)
}