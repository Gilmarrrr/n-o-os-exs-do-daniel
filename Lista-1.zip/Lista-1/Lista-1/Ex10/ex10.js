function calcular() {
    let l = Number(document.getElementById("l").value)
    let a = l * l
    alert(`A área do quadrado de lado ${l} cm é ${a} cm².`)
}