function enviar() {
    alert(res)
}
let res = function calcular() {
    const n = Number(document.getElementById("n").value)
    let r = document.getElementById("resposta")
    for(let a = 1; a <= 10; a++) {
        (`${n} x ${a} = ${n * a}`)
    }
    return
}
/*const n = 3
    for(let a = 1; a <= 10; a++) {
        console.log(`${n} x ${a} = ${n * a}`)
    }
    */
console.log(enviar)