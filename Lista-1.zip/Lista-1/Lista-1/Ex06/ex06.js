function ex06() {
    let salarioF = Number(document.getElementById("SalarioF").value)
    let vendas = Number(document.getElementById("vendas").value)
    let comissão = (vendas * 0.4).toLocaleString('pt-BR', {style: 'currency', currency: 'BRL'})
    let respostaC = document.getElementById("respostaC")
    let final = (salarioF + comissão).toLocaleString('pt-BR', {style: 'currency', currency: 'BRL'})
    let respostaF = document.getElementById("respostaF")

    respostaC.innerHTML = (`A comissão é de ${comissão} reais.`)
    respostaF.innerHTML = (`O salário final é ${final} reais.`)
}

