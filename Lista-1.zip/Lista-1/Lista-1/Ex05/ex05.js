function calcular() {
    let n = Number(document.getElementById("n").value)
    let desconto = n * 0.1
    let precoF = (n - desconto).toLocaleString('pt-BR', {style: 'currency', currency: 'BRL'})
    alert(`O preço final é ${precoF}.`)
}