function calcular() {
    let p = Number(document.getElementById("p").value)
    let pEN = p + (p * 0.15)
    let pEM = p - (p * 0.2)
    alert(`Seu peso atual é ${p}, caso ganhe 15% seu peso se torna ${pEN.toFixed(2)}kg, caso perca 20% seu peso se torna ${pEM.toFixed(2)}kg.`)
}
let ex = 8
console.log(`A varaivel ex é: ${ex}`)
console.log("A variavel ex é: " + ex)
