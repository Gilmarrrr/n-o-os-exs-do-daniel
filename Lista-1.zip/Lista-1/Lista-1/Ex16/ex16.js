function calcular() {
    let c1 = Number(document.getElementById("c1").value)
    let c2 = Number(document.getElementById("c2").value)
    let r = document.getElementById("res")
    let h = (c1 * c1) + (c2 * c2)
    r.innerHTML = (`A hipotenusa é: ${h}cm.`)
}