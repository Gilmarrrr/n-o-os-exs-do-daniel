function calcular() {
    let C = Number(document.getElementById("C").value)
    let L = Number(document.getElementById("L").value)
    let A = C * L
    let P = A * 18
    alert(`Na casa com área de ${A.toFixed(2)}m² e para iluminar toda sua área é preciso ${P.toFixed(2)}W.`)
}