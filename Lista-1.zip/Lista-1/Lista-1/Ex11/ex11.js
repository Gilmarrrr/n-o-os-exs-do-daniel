function calcular() {
    let dMaior = Number(document.getElementById("dMaior").value)
    let dMenor = Number(document.getElementById("dMenor").value)
    let a = (dMaior + dMenor) / 2 
    alert(`A área deste losango é ${a} cm.`)
}