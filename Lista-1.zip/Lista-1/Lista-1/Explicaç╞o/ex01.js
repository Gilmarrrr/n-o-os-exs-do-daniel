function calcular() {
    let n1 = Number(document.getElementById("n1").value)
    let n2 = Number(document.getElementById("n2").value)
    let res = n1 - n2
    alert("O resultado da subtração é: " + res)
}