function calcular() {
    let salario = Number(document.getElementById("n").value)
    let contas = Number(document.getElementById("contas").value)
    let juros = salario * 0.2
    while(contas > 0) {
        var r = (salario - juros).toLocaleString('pt-br', {style: 'currency', currency: 'BRL'})
        contas--
    }
    alert(`O salario restante de João é: ${r}`)
}