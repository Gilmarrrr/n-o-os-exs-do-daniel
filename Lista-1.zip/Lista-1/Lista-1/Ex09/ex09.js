function calcular() {
    let bmaior = Number(document.getElementById("bmaior").value)
    let bmenor = Number(document.getElementById("bmenor").value)
    let h = Number(document.getElementById("altura").value)
    let a = ((bmaior + bmenor) * altura) / 2
    alert(`A aréa deste trapezio é: ${a} cm².`)
}