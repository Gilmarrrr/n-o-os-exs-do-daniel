function calcular() {
    let n1 = Number(document.getElementById("n1").value)
    let n2 = Number(document.getElementById("n2").value)
    let subtracao = n1 - n2
    alert(`A subtração entre esses numeros é: ${subtracao}`)
}