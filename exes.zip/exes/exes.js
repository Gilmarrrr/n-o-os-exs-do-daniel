//exe3

function menor(){
    let n1 = Number(document.getElementById("n1").value)
    let n2 = Number(document.getElementById("n2").value)

    if(n1 < n2){
        alert(n1 + " é menor")
    }
    else{
        alert(n2 + " é menor")
    }
}

//exe4

function maior(){
    let n1 = Number(document.getElementById("n1").value)
    let n2 = Number(document.getElementById("n2").value)

    if(n1 > n2){
        alert(n1 + " é maior")
    }
    else{
        alert(n2 + " é maior")
    }
}

//exe5

function calc(){
    let n1 = Number(document.getElementById("n1").value)
    let n2 = Number(document.getElementById("n2").value)
    let select = Number(document.getElementById("select").value)

    let resultado
    switch(select){
        case 1:
            resultado = (n1 + n2)/2
            break;
        case 2:
            resultado = (n1 * n2)
            break;
        case 3:
                if (n1 > n2){
                    resultado = n1 - n2
                }
                else{
                    resultado = n2 - n1
                }
            break;
        case 4:
            if(n2 == '0'){
                resultado = "O segundo número não pode ser zero";
            }
            else{
                resultado = n1 / n2
            }
            break;
    } 
    document.getElementById("resultado").innerHTML = resultado
}

//exe6

function exe6(){
    let n1 = Number(document.getElementById("n1").value)
    let n2 = Number(document.getElementById("n2").value)
    let select = Number(document.getElementById("select").value)

    let resultado
    let resultado1
    let resultado2
    switch(select){
        case 1:
            resultado = Math.pow(n1, n2);
            alert(resultado)
            break
        case 2:
            resultado1 = Math.sqrt(n1)
            resultado2 = Math.sqrt(n2)
            alert("a raiz quadrada do primeiro é " + resultado1 + " e a do segundo é " + resultado2)
            break
        case 3:
            resultado1 = Math.cbrt(n1)
            resultado2 = Math.cbrt(n2)
            alert("a raiz cubica do primeiro é " + resultado1 + " e a do segundo é " + resultado2)
            break
    } 
}

//exe7

function exe7(){
    let salario = Number(document.getElementById("salario").value)

    let result
    if(salario<500){
        result = salario + (30/100 * salario)
        document.getElementById("erro").innerHTML = ""
        document.getElementById("text").innerHTML = "Seu novo salário sera de " + result
    }
    else if(salario>=500){
        document.getElementById("text").innerHTML = ""
        document.getElementById("erro").innerHTML = "Você não tem direito á aumento de salário!"
    }
}