const calculos = {
    ex01() {
        let n1 = Number(document.getElementById('n1').value)
        let n2 = Number(document.getElementById('n2').value)
        let n3 = Number(document.getElementById('n3').value)
        let n4 = Number(document.getElementById('n4').value)
        let media = (n1 + n2 + n3 + n4) / 4
        if(media >= 7) {
            alert(`Sua média foi ${media.toFixed(1)}, você passou!`)
        } else {
            alert(`Sua média foi ${media.toFixed(1)}, você não passou!`)
        }
    },
    ex02() {
        let n1 = Number(document.getElementById('n1').value)
        let n2 = Number(document.getElementById('n2').value)
        let media = (n1 + n2) / 2
        if (media < 3) {
            alert(`Sua média foi ${media.toFixed(1)}, você foi reprovado!`)
        } else if (media >= 3 && media < 7) {
            alert(`Sua média foi ${media.toFixed(1)}, você está de exame!`)
        } else if (media >= 7 && media <= 10) { //validação de nota valida
            alert(`Sua média foi ${media.toFixed(1)}, você foi aprovado!`)
        } else {
            alert(`Sua média é invalida tente novamente.`)
        }
    },
    ex03() {
        let n1 = Number(document.getElementById('n1').value)
        let n2 = Number(document.getElementById('n2').value)
        if (n1 < n2) {
            alert(n1)
        } else {
            alert(n2)
        }
    },
    ex04() {
        let n1 = Number(document.getElementById('n1').value)
        let n2 = Number(document.getElementById('n2').value)
        if (n1 > n2) {
            alert(n1)
        } else {
            alert(n2)
        }
    },
    ex05() {
        let n1 = Number(document.getElementById('n1').value)
        let n2 = Number(document.getElementById('n2').value)
        let sl = Number(document.getElementById('selecao').value)
        switch(sl) {
            case 1:
                alert(`A média entre ${n1} e ${n2} é ${(n1 + n2) / 2}.`)
            break
            case 2:
                if (n1 >= n2) {
                    alert(`A diferença entre o maior pelo menor é ${n1 - n2}.`)
                } else {
                    alert(`A diferença entre o maior pelo menor é ${n2 - n1}.`)
                }
            break
            case 3:
                alert(`O produto entre ${n1} e ${n2} é ${n1 * n2}`)
            break
            case 4:
                if (n2 != 0) {
                    alert(`A divisão entre ${n1} e ${n2} é ${n1 / n2}.`)
                } else {
                    alert(`O numero 2 tem que ser diferente de 0!`)
                }
        }
    },
}
